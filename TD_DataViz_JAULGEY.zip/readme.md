### Librairie utilisée
d3.js

### Graphe utilisé pour afficher les données de Voltage et Energie
Line chart : permet de suivre l'évolution des données dans le temps

2 axes en ordonnées : permet d'avoir 2 échelles différentes pour les données de l'énergie et du voltage car les valeurs sont très différentes donc avec 1 seule échelle le voltage aurait été écrasé par l'énergie.

Valeurs des axes en ordonnée : j'ai fait le choix de ne pas partir de 0 mais d'une valeur plus élevée pour que les courbes soient le moins ecrasées possibles et donc plus lisibles/visuelles.

### Graphe utilisé pour afficher les données d'usage des téléphones / du sommeil / du sport en DE3
J'ai fait le choix d'utiliser un radar chart permettant de représenter pour chaque élève les différentes valeurs mesurées.

Le fait que ce soit un radar chart permet de voir une évolution entre chaque élève de manière centralisée par le centre du cercle.
Cela permet aussi de voir l'évolution à l'aide de la coloration des zones deopuis le centre jusqu'aux lignes des valeurs.

### © Thomas JAULGEY